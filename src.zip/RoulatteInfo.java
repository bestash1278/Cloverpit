/**
 * UserInfo.java (임시 파일: PaymentScreen 디버깅용)
 */
public class RoulatteInfo {
    
    private int roulatte_cost = 2; 


    public RoulatteInfo() {
        // 기본 생성자 
    }

    // 룻렛 1회 비용
    public int get_roulatte_cost() {
        return roulatte_cost;
    }

}